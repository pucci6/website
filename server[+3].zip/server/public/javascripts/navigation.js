// Set the nav menu visibility, depending on whether the page is viewed on a mobile or desktop:
var navHidden = false;

function navVisibility() {
    let nav = document.getElementsByTagName('nav')[0];
    let hideNav = window.matchMedia("(max-width: 768px)").matches;
    if (navHidden != hideNav) {
        navHidden = hideNav;

        if (navHidden) {
            nav.hidden = true;
        } else {
            nav.hidden = false;
        }
    }
}

navVisibility();

window.addEventListener("resize", navVisibility);