var express = require('express');
var router = express.Router();

router.post('/register-health-official', function(req, res, next) {
    let email = req.body;

    req.pool.getConnection(function(err, connection) {
        var checkInQuery = "INSERT INTO pending_admins email VALUES (?);";
        connection.query(checkInQuery, [email], function(err, rows, fields) {
            connection.release();
            if (err) {
               console.log(err);
               res.sendStatus(500);
               return;
            }

            res.json();
        });
    });

    // Send email to new admin:
    // Test

    // HERE
});

module.exports = router;