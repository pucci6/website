function revert() {
    location.reload();
}

function apply() {
    // Send POST request to server, containing the updated account details.
    var xhttp = new XMLHttpRequest();

    xhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            location.reload();
        }
    };

    xhttp.open("POST", "/user/details", true);
    xhttp.setRequestHeader('Content-type', 'application/json');
    xhttp.send(JSON.stringify(vm.user));
}

var vm = new Vue({
    el: '#app',
    data: {
        user: {}
    }
});

var xhttp = new XMLHttpRequest();

xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
        vm.user = JSON.parse(this.responseText);
    }
};

xhttp.open("GET", "/user/details", true);
xhttp.send();

function validatePassword() {
    var password = document.getElementById("password");
    var confirmPassword = document.getElementById("password-confirm");

    if (String(password.value) != String(confirmPassword.value)) {
        confirmPassword.setCustomValidity("Passwords must match.");
    } else {
        confirmPassword.setCustomValidity("");
    }
}