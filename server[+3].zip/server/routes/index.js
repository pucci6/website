var express = require('express');
var router = express.Router();
var path = require('path');
var argon2 = require('argon2');
var crypto = require('crypto');
var XMLHttpRequest = require("xmlhttprequest").XMLHttpRequest;

var googleClientId = "236702098774-31knb831of37746gcs9js747kuneh8df.apps.googleusercontent.com";
/*
router.use('*', function(req, res, next) {
    if ('user' in req.session) {
        next();
    } else {
        res.redirect('/login.html');
        //res.sendFile(path.join(__dirname, 'pages/index.html'));
    }
});*/

router.get('/', function(req, res, next) {
    if ('user' in req.session) {
        next();
    } else {
        res.redirect('/login.html');
        //res.sendFile(path.join(__dirname, 'pages/index.html'));
    }
});

router.get('/index.html', function(req, res, next) {
    if ('user' in req.session) {
        next();
    } else {
        res.redirect('/login.html');
        //res.sendFile(path.join(__dirname, 'pages/index.html'));
    }
});

router.post('/login', function(req, res, next) {
    if ('email' in req.body && 'password' in req.body) {
        req.pool.getConnection(function(err, connection) {
           if (err) {
               console.log(err);
               res.sendStatus(500);
               return;
           }

           var loginQuery = "SELECT * FROM user WHERE email = ?;";
           connection.query(loginQuery, [req.body.email], async function(err, rows, fields) {
               connection.release();
               if (err) {
                   console.log(err);
                   res.sendStatus(500);
                   return;
                }

                if (rows.length > 0) {
                    let validate = await argon2.verify(rows[0].password_hash, req.body.password);

                    if (validate) {
                        delete rows[0].password_hash;
                        req.session.user = rows[0];
                        res.send(req.session.user);
                    } else {
                        res.sendStatus(400);
                    }
                } else {
                    res.sendStatus(400);
                }
            });
        });
    } else if ('token' in req.body) {
        // Verify OpenID token.
        const {OAuth2Client} = require('google-auth-library');
        const client = new OAuth2Client(googleClientId);
        async function verify() {
            const ticket = await client.verifyIdToken({
                idToken: req.body.token,
                audience: googleClientId
            });
            const payload = ticket.getPayload();
            const userid = payload['sub'];

            req.pool.getConnection(function(err, connection) {
                if (err) {
                    console.log(err);
                    res.sendStatus(500);
                    return;
                }

                var loginQuery = "SELECT * FROM user WHERE email = ?;";
                connection.query(loginQuery, [payload.email], async function(err, rows, fields) {
                    connection.release();
                    if (err) {
                        console.log(err);
                        res.sendStatus(500);
                        return;
                    }

                    if (rows.length > 0) {
                        req.session.user = rows[0];
                        res.send(rows[0]);
                    } else {
                        req.pool.getConnection(function(err, connection) {
                            if (err) {
                                console.log(err);
                                res.sendStatus(500);
                                return;
                            }

                            var loginQuery = "INSERT INTO user (email, given_name, family_name) VALUES (?);";
                            connection.query(loginQuery, [payload.email, payload.given_name, payload.family_name], async function(err, rows, fields) {
                                connection.release();
                                if (err) {
                                    console.log(err);
                                    res.sendStatus(500);
                                    return;
                                }

                                res.send(rows[0]);
                            });
                        });
                    }
                });
            });
        }
        verify().catch(console.error);
    }
});

router.post('/register', function(req, res, next) {
    if ('email' in req.body && 'givenName' in req.body && 'familyName' in req.body && 'phone' in req.body && 'password' in req.body) {
        let userType = 'user';
        if ('venue' in req.body) {
            if ('name' in req.body.venue && 'streetNo' in req.body.venue && 'streetName' in req.body.venue && 'city' in req.body.venue && 'postcode' in req.body.venue) {
                userType = 'venue-owner';
            } else {
               res.sendStatus(400);
               return;
            }
        }

        req.pool.getConnection(function(err, connection) {
            if (err) {
                console.log(err);
                res.sendStatus(500);
                return;
            }

            crypto.randomBytes(16, async function(err, salt) {
                if (err) {
                    console.log(err);
                    res.sendStatus(500);
                    return;
                }
                let passwordHash = await argon2.hash(req.body.password, salt);

                var registerQuery = "INSERT INTO user (given_name, family_name, email, phone, password_hash, account_type) VALUES (?, ?, ?, ?, ?, ?);";
                connection.query(registerQuery, [req.body.givenName, req.body.familyName, req.body.email, req.body.phone, passwordHash, userType], function(err, rows, fields) {
                    connection.release();
                    if (err) {
                       console.log(err);
                       res.sendStatus(500);
                       return;
                    }

                    if (userType == 'venue-owner') {
                        let venue = req.body.venue;
                        let address = encodeURIComponent(`${venue.streetNo} ${venue.streetName}, ${venue.city} ${venue.postcode} ${venue.state}`);

                        var xhttp = new XMLHttpRequest();

                        xhttp.onreadystatechange = function() {
                            if (this.readyState == 4 && this.status == 200) {
                                let mapboxData = JSON.parse(this.responseText);

                                req.pool.getConnection(function(err, connection) {
                                    if (err) {
                                        console.log(err);
                                        res.sendStatus(500);
                                        return;
                                    }

                                    var createVenueQuery = "INSERT INTO venue (name, owner, latitude, longitude, state, city, postcode, street_name, street_number) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?);";
                                    connection.query(createVenueQuery, [venue.name, rows.insertId, mapboxData.features[0].center[0], mapboxData.features[0].center[1], venue.state, venue.city, venue.postcode, venue.streetName, venue.streetNo], function(err, rows, fields) {
                                        connection.release();
                                        if (err) {
                                           console.log(err);
                                           res.sendStatus(500);
                                           return;
                                        }

                                        res.sendStatus(200);
                                    });
                                });
                            } else if (this.readyState == 4) {
                                res.sendStatus(400);
                            }
                        };

                        xhttp.open("GET", "https://api.mapbox.com/geocoding/v5/mapbox.places/" + address + ".json?limit=1&access_token=pk.eyJ1Ijoid2RjLXByb2plY3QiLCJhIjoiY2tvYzlsNW54MHNqZTMwb3k1ZjJlM3d2YyJ9.uD5DPRQ6JiUzECtpkOw8LA", true);
                        xhttp.send();
                    } else {
                        res.sendStatus(200);
                    }
                });
           });
        });
    } else {
        res.sendStatus(400);
    }
});

module.exports = router;
