function validateLogin() {
    let user = {
        email: document.getElementById('email').value,
        password: document.getElementById('password').value
    };

    var xhttp = new XMLHttpRequest();

    xhttp.onreadystatechange = function() {
        if (this.readyState == 4) {
            if (this.status == 200) {
                let userData = JSON.parse(this.responseText);
                document.cookie = "userType=" + userData.account_type + ";path=/";
                window.location.href = "/";
            } else if (this.status == 400) {
                console.log("Incorrect login details");
            }
        }
    };

    xhttp.open("POST", "/login", true);
    xhttp.setRequestHeader('Content-type', 'application/json');
    xhttp.send(JSON.stringify(user));

    return false;
}

function onSignIn(googleUser) {
    var profile = googleUser.getBasicProfile();
    console.log('ID: ' + profile.getId()); // Do not send to your backend! Use an ID token instead.
    console.log('Name: ' + profile.getName());
    console.log('Image URL: ' + profile.getImageUrl());
    console.log('Email: ' + profile.getEmail()); // This is null if the 'email' scope is not present.


    var id_token = googleUser.getAuthResponse().id_token;
    var xhr = new XMLHttpRequest();
    xhr.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            let userData = JSON.parse(this.responseText);
            document.cookie = "userType=" + userData.account_type + ";path=/";
            window.location.href = "/";
        }
    };
    xhr.open('POST', '/login', true);
    xhr.setRequestHeader('Content-type', 'application/json');
    xhr.send(JSON.stringify({token: id_token}));
}