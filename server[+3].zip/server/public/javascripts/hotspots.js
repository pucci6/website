var vm = new Vue({
    el: '#app',
    data: {
        hotspot_visit: 0,
        hotspot_venues: [],
        hotspot_areas: []
    }
});

mapboxgl.accessToken = 'pk.eyJ1Ijoid2RjLXByb2plY3QiLCJhIjoiY2tvYzlsNW54MHNqZTMwb3k1ZjJlM3d2YyJ9.uD5DPRQ6JiUzECtpkOw8LA';
var map = new mapboxgl.Map({
    container: 'map',
    style: 'mapbox://styles/mapbox/streets-v11',
    center: [138.602668, -34.920741],
    zoom: 9
});

var xhttp = new XMLHttpRequest();

xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
        let hotspots = JSON.parse(this.responseText);
        vm.hotspot_venues = hotspots.venues;
        vm.hotspot_areas = hotspots.areas;

        // Mark hotspot venues:
        for (let venue of vm.hotspot_venues) {
            let marker = new mapboxgl.Marker()
            .setLngLat([venue.longitude, venue.latitude])
            .addTo(map);
        }

        // Mark hotspot areas:
        for (let area of vm.hotspot_areas) {
            let id = area.city;
            map.addSource(id, {
                'type': 'geojson',
                'data': {
                'type': 'Feature',
                'geometry': {
                    'type': 'Polygon',
                    'coordinates': area.coords
                    }
                }
            });

            map.addLayer({
                'id': id,
                'type': 'fill',
                'source': id,
                'layout': {},
                'paint': {
                    'fill-color': '#ff0000',
                    'fill-opacity': 0.5
                }
            });

            map.addLayer({
                'id': id + ' outline',
                'type': 'line',
                'source': id,
                'layout': {},
                'paint': {
                    'line-color': '#000000',
                    'line-width': 3
                }
            });
        }
    }
};

xhttp.open("GET", "/user/hotspots", true);
xhttp.send();