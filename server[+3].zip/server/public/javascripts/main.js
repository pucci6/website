var userCheckIns = [{"address":"5 Murranji St, Hawker 2614 ACT","name":"D'ASCANIO MOTOR REPAIRS","date":"13/05/2021","time":"6:54 PM","latitude":-35.241449,"longitude":149.033248},{"address":"67 Fyans St, South Geelong 3220 VIC","name":"EMPACT NAILS","date":"12/05/2021","time":"10:30 AM","latitude":-38.162117,"longitude":144.356404},{"address":"122 Smiths Rd, Emerald Beach 2456 NSW","name":"ORBIO","date":"11/05/2021","time":"8:33 AM","latitude":-30.17007,"longitude":153.157732},{"address":"2 Edinburgh Ave, Canberra 2601 ACT","name":"PARKHILL CONSTRUCTIONS","date":"9/05/2021","time":"11:44 PM","latitude":-35.283193,"longitude":149.124778},{"address":"90 Kereela Drv, Girraween 836 NT","name":"IT4MULA","date":"9/05/2021","time":"12:40 PM","latitude":-12.533618,"longitude":131.096283},{"address":"49 Knuckey St, Darwin 800 NT","name":"COASTAL LASHES & BEAUTY","date":"8/05/2021","time":"3:44 PM","latitude":-12.46051,"longitude":130.843788},{"address":"329 Hawthorn Rd, Caulfield 3162 VIC","name":"Tam Uzoma Makeup Artistry","date":"7/05/2021","time":"4:44 PM","latitude":-37.884678,"longitude":145.022606},{"address":"17 Euroka St, Ingleburn 2565 NSW","name":"HEART CULTURE","date":"6/05/2021","time":"2:08 PM","latitude":-34.006571,"longitude":150.860908},{"address":"41 Prince St, Paddington 4064 QLD","name":"GROWING THRU' TRANSITIONS","date":"5/05/2021","time":"2:28 AM","latitude":-32.06454,"longitude":115.97774},{"address":"4 Collier Pl, Kalgoorlie 6430 WA","name":"Dirty Days Apparel","date":"4/05/2021","time":"2:40 AM","latitude":-30.76557,"longitude":121.47719},{"address":"64 Niagara St, Armidale 2350 NSW","name":"MELBOURNE SANCTUARY MANAGEMENT SERVICES","date":"3/05/2021","time":"6:21 PM","latitude":-30.504048,"longitude":151.65191},{"address":"954 Sylvania Ave, North Albury 2640 NSW","name":"POSICOTE RENDERING","date":"2/05/2021","time":"6:14 PM","latitude":-36.059351,"longitude":146.931268},{"address":"3 Maxlay Rd, Modbury Heights 5092 SA","name":"Charles Lloyd Property Group","date":"1/05/2021","time":"1:14 PM","latitude":-34.810945,"longitude":138.677184},{"address":"14 Glen Eagles Way, Prospect 7250 TAS","name":"HOLTFRETERS","date":"30/04/2021","time":"8:58 AM","latitude":-41.4833,"longitude":147.14},{"address":"29 Kathleen St, Morwell 3840 VIC","name":"KITCHEN CABINETS WA","date":"29/04/2021","time":"5:13 AM","latitude":-38.220819,"longitude":146.422633},{"address":"9 College Pl, Bowral 2576 NSW","name":"Territory Liberal Party","date":"28/04/2021","time":"5:04 AM","latitude":-34.489661,"longitude":150.428203},{"address":"329 Hawthorn Rd, Caulfield 3162 VIC","name":"Tam Uzoma Makeup Artistry","date":"27/04/2021","time":"5:05 AM","latitude":-37.884678,"longitude":145.022606},{"address":"13 Park St, Moonee Ponds 3039 VIC","name":"SCHOOL OF PD","date":"26/04/2021","time":"10:25 AM","latitude":-37.762255,"longitude":144.920368},{"address":"232 Goondoon St, South Gladstone 4680 QLD","name":"WA TREASURE HUNT","date":"25/04/2021","time":"7:27 AM","latitude":-23.852429,"longitude":151.26192},{"address":"18 Rundle St, Wodonga 3690 VIC","name":"M & J SCRAPPING","date":"24/04/2021","time":"4:49 PM","latitude":-36.135027,"longitude":146.883212}];
var pendingRegistrations = [
    {
        email: "joey.price2323@gmail.com",
        expires: "5/13/2021, 5:34:22 AM"
    },
    {
        email: "jasper.shaw7528@gmail.com",
        expires: "5/14/2021, 3:56:65 PM"
    },
    {
        email: "melissa.walker7001@gmail.com",
        expires: "5/21/2021, 7:12:45 PM"
    }
];
var venue_checkin_history = [{"familyName":"Shaw","givenName":"Zac","date":"13/05/2021","time":"7:09 PM"},{"familyName":"Walker","givenName":"Abby","date":"13/05/2021","time":"6:28 PM"},{"familyName":"Kelly","givenName":"Brandon","date":"13/05/2021","time":"6:24 PM"},{"familyName":"Ross","givenName":"Madeleine","date":"13/05/2021","time":"5:45 PM"},{"familyName":"Cooper","givenName":"Chelsea","date":"13/05/2021","time":"4:51 PM"},{"familyName":"Parker","givenName":"Harry","date":"13/05/2021","time":"4:01 PM"},{"familyName":"Young","givenName":"Max","date":"13/05/2021","time":"3:09 PM"},{"familyName":"Hamilton","givenName":"Aaron","date":"13/05/2021","time":"2:49 PM"},{"familyName":"Mitchell","givenName":"Steph","date":"13/05/2021","time":"2:16 PM"},{"familyName":"Walker","givenName":"Jacinta","date":"13/05/2021","time":"2:09 PM"},{"familyName":"Shaw","givenName":"Ellie","date":"13/05/2021","time":"1:52 PM"},{"familyName":"Chapman","givenName":"Corey","date":"13/05/2021","time":"1:48 PM"},{"familyName":"Butler","givenName":"Sean","date":"13/05/2021","time":"1:32 PM"},{"familyName":"Phillips","givenName":"Shaun","date":"13/05/2021","time":"1:06 PM"},{"familyName":"McDonald","givenName":"Luke","date":"13/05/2021","time":"12:50 PM"},{"familyName":"Davis","givenName":"Brooke","date":"13/05/2021","time":"12:22 PM"},{"familyName":"Edwards","givenName":"Chelsea","date":"13/05/2021","time":"11:47 AM"},{"familyName":"Hall","givenName":"Charlie","date":"13/05/2021","time":"11:22 AM"},{"familyName":"Stevens","givenName":"Harrison","date":"13/05/2021","time":"11:22 AM"},{"familyName":"Reid","givenName":"Jade","date":"13/05/2021","time":"10:54 AM"},{"familyName":"Gray","givenName":"Brandon","date":"13/05/2021","time":"10:02 AM"},{"familyName":"Baker","givenName":"Steven","date":"13/05/2021","time":"9:04 AM"},{"familyName":"Ryan","givenName":"Matthew","date":"13/05/2021","time":"8:29 AM"},{"familyName":"Davies","givenName":"Connor","date":"13/05/2021","time":"7:41 AM"},{"familyName":"Johnston","givenName":"Maddie","date":"13/05/2021","time":"7:19 AM"},{"familyName":"Morris","givenName":"Riley","date":"13/05/2021","time":"6:44 AM"},{"familyName":"Richardson","givenName":"Hamish","date":"13/05/2021","time":"6:34 AM"},{"familyName":"Jackson","givenName":"Shaun","date":"13/05/2021","time":"6:18 AM"},{"familyName":"Carter","givenName":"Leah","date":"13/05/2021","time":"6:17 AM"},{"familyName":"Taylor","givenName":"Madison","date":"13/05/2021","time":"5:24 AM"},{"familyName":"Young","givenName":"Jessie","date":"13/05/2021","time":"5:23 AM"},{"familyName":"Stevens","givenName":"Ryan","date":"13/05/2021","time":"4:27 AM"},{"familyName":"Morris","givenName":"Chris","date":"13/05/2021","time":"3:59 AM"},{"familyName":"Shaw","givenName":"Sean","date":"13/05/2021","time":"3:30 AM"},{"familyName":"Morgan","givenName":"Samantha","date":"13/05/2021","time":"2:45 AM"},{"familyName":"Graham","givenName":"Rachael","date":"13/05/2021","time":"1:54 AM"},{"familyName":"Chapman","givenName":"Mark","date":"13/05/2021","time":"12:59 AM"},{"familyName":"Wood","givenName":"Tony","date":"13/05/2021","time":"12:06 AM"},{"familyName":"Clark","givenName":"Nicole","date":"12/05/2021","time":"11:34 PM"},{"familyName":"Rogers","givenName":"Jim","date":"12/05/2021","time":"10:46 PM"},{"familyName":"Edwards","givenName":"Kieran","date":"12/05/2021","time":"9:49 PM"},{"familyName":"Carter","givenName":"Tegan","date":"12/05/2021","time":"9:34 PM"},{"familyName":"Thomson","givenName":"Kyle","date":"12/05/2021","time":"8:41 PM"},{"familyName":"Matthews","givenName":"Sophie","date":"12/05/2021","time":"8:30 PM"},{"familyName":"Mitchell","givenName":"Scott","date":"12/05/2021","time":"8:17 PM"},{"familyName":"Miller","givenName":"Bethany","date":"12/05/2021","time":"7:40 PM"},{"familyName":"Davies","givenName":"Connor","date":"12/05/2021","time":"6:42 PM"},{"familyName":"Thompson","givenName":"Jessie","date":"12/05/2021","time":"6:18 PM"},{"familyName":"Hughes","givenName":"Brayden","date":"12/05/2021","time":"5:59 PM"},{"familyName":"Nguyen","givenName":"Caitlyn","date":"12/05/2021","time":"5:00 PM"},{"familyName":"Carter","givenName":"Jim","date":"12/05/2021","time":"4:46 PM"},{"familyName":"Green","givenName":"Julia","date":"12/05/2021","time":"3:56 PM"},{"familyName":"Harvey","givenName":"Annie","date":"12/05/2021","time":"3:17 PM"},{"familyName":"Roberts","givenName":"Ryan","date":"12/05/2021","time":"2:26 PM"},{"familyName":"Hamilton","givenName":"Abby","date":"12/05/2021","time":"2:15 PM"},{"familyName":"Murray","givenName":"Rachael","date":"12/05/2021","time":"1:21 PM"},{"familyName":"Cook","givenName":"Grace","date":"12/05/2021","time":"12:52 PM"},{"familyName":"Graham","givenName":"Brooke","date":"12/05/2021","time":"12:30 PM"},{"familyName":"Jackson","givenName":"Hamish","date":"12/05/2021","time":"11:43 AM"},{"familyName":"Stewart","givenName":"Bella","date":"12/05/2021","time":"11:10 AM"},{"familyName":"Robinson","givenName":"Tim","date":"12/05/2021","time":"10:52 AM"},{"familyName":"Young","givenName":"Jackson","date":"12/05/2021","time":"10:41 AM"},{"familyName":"Harvey","givenName":"Aaron","date":"12/05/2021","time":"10:37 AM"},{"familyName":"Murray","givenName":"Jessica","date":"12/05/2021","time":"9:53 AM"},{"familyName":"Green","givenName":"Abbie","date":"12/05/2021","time":"9:35 AM"},{"familyName":"Cameron","givenName":"Erin","date":"12/05/2021","time":"8:52 AM"},{"familyName":"Johnston","givenName":"Shane","date":"12/05/2021","time":"8:14 AM"},{"familyName":"White","givenName":"Stephanie","date":"12/05/2021","time":"7:54 AM"},{"familyName":"Allen","givenName":"Hugo","date":"12/05/2021","time":"7:53 AM"},{"familyName":"Martin","givenName":"Claire","date":"12/05/2021","time":"7:48 AM"},{"familyName":"Jones","givenName":"Kevin","date":"12/05/2021","time":"6:56 AM"},{"familyName":"Adams","givenName":"Kate","date":"12/05/2021","time":"6:36 AM"},{"familyName":"Robertson","givenName":"Mitch","date":"12/05/2021","time":"6:31 AM"},{"familyName":"Taylor","givenName":"Jonathan","date":"12/05/2021","time":"6:18 AM"},{"familyName":"Taylor","givenName":"Steven","date":"12/05/2021","time":"5:30 AM"},{"familyName":"Morgan","givenName":"Shaun","date":"12/05/2021","time":"5:28 AM"},{"familyName":"Hamilton","givenName":"William","date":"12/05/2021","time":"4:29 AM"},{"familyName":"Walker","givenName":"Taylor","date":"12/05/2021","time":"3:40 AM"},{"familyName":"James","givenName":"Jessica","date":"12/05/2021","time":"3:26 AM"},{"familyName":"Harrison","givenName":"Matthew","date":"12/05/2021","time":"2:50 AM"},{"familyName":"Wilson","givenName":"Brock","date":"12/05/2021","time":"2:41 AM"},{"familyName":"Hill","givenName":"Grace","date":"12/05/2021","time":"2:31 AM"},{"familyName":"Carter","givenName":"Lauren","date":"12/05/2021","time":"2:00 AM"},{"familyName":"Taylor","givenName":"Isaac","date":"12/05/2021","time":"1:13 AM"},{"familyName":"Wright","givenName":"Riley","date":"12/05/2021","time":"12:14 AM"},{"familyName":"Pearce","givenName":"Olivia","date":"12/05/2021","time":"12:05 AM"},{"familyName":"Harris","givenName":"Molly","date":"12/05/2021","time":"12:00 AM"},{"familyName":"Allen","givenName":"Zachary","date":"11/05/2021","time":"11:05 PM"},{"familyName":"Richardson","givenName":"Madeleine","date":"11/05/2021","time":"10:28 PM"},{"familyName":"James","givenName":"Blake","date":"11/05/2021","time":"9:46 PM"},{"familyName":"Richardson","givenName":"Claudia","date":"11/05/2021","time":"8:51 PM"},{"familyName":"Ward","givenName":"Julia","date":"11/05/2021","time":"7:54 PM"},{"familyName":"Ward","givenName":"Julia","date":"11/05/2021","time":"7:52 PM"},{"familyName":"Chapman","givenName":"Josh","date":"11/05/2021","time":"6:52 PM"},{"familyName":"Hughes","givenName":"Claudia","date":"11/05/2021","time":"5:59 PM"},{"familyName":"Clarke","givenName":"Lauren","date":"11/05/2021","time":"5:41 PM"},{"familyName":"Elliott","givenName":"Bianca","date":"11/05/2021","time":"4:41 PM"},{"familyName":"Stevens","givenName":"Jade","date":"11/05/2021","time":"3:51 PM"},{"familyName":"Matthews","givenName":"Taylor","date":"11/05/2021","time":"3:18 PM"},{"familyName":"Elliott","givenName":"Gus","date":"11/05/2021","time":"2:51 PM"}];
var venue_owner = {"userId":0,"givenName":"Holly","familyName":"Richardson","streetNo":"21","streetName":"Traynor Crt","city":"Melba","postcode":2615,"state":"ACT","phone":"+61013179986","email":"holly.richardson418@gmail.com"};


var vm = new Vue({
   el: '#app',
   data: {
        page: 'dashboard',
        user: {
            accountType: ''
        },

        cases: [],
        deaths: [],
        info: [],
        hotspot_visit: -1,
        settings: {},

        code: '',
        checkin_status: -1,
        checkin: {},

        checkins: [],
        venue: {},

        hotspot_venues: [],
        hotspot_areas: [],
        areas: false,


        users: [],
        search_data: {
            term: "",
            by: ""
        },
        pg: 1,
        input_page: 1,
        page_size: 10,
        managing_user: false,
        viewing_checkins: false,
        checkin_history: userCheckIns,
        venues: [],
        managing_venue: false,
        viewing_owner: false,
        owner: {},
        active_user: {},
        active_venue: {},

        pending: pendingRegistrations
   },
   methods: {
        manage_user: function(i) {
            this.managing_user = true;
            this.active_user = this.users[i];
        },
        view_checkin_history: function(i) {
            this.viewing_checkins = true;
            this.checkin_history = userCheckIns;
        },
        manage_venue: function(i) {
            this.managing_venue = true;
            this.venue = this.venues[i];
        },
        view_venue_checkin_history: function(i) {
            this.viewing_checkins = true;
            this.checkin_history = venue_checkin_history;
        },
        view_owner: function(i) {
            this.viewing_owner = true;
            this.owner = venue_owner;
        },
        cancelPendingRegistration: function(email) {
            // Send POST request to server, to cancel admin registration for given email address.
        }
   },
   computed: {
        getVenueCheckInHistory: function() {
            if (this.page == 'venue-check-in-history') {
                var xhttp = new XMLHttpRequest();

                xhttp.onreadystatechange = function() {
                    if (this.readyState == 4 && this.status == 200) {
                        vm.checkins = JSON.parse(this.responseText);
                    }
                };

                xhttp.open("GET", "/manager/check-in-history", true);
                xhttp.send();
                return true;
            } else {
                return false;
            }
        },
        getCheckInHistory: function() {
            setTimeout(updateCheckInMap, 1);
            return true;
        },
        getHotspots: function() {
            setTimeout(updateHotspotMap, 1);
            return true;
        },
        viewPage: function() {
            return Math.max(1, parseInt(this.pg));
        },
        getCheckIn: function() {
            let queryIndex = window.location.href.indexOf('?');
            if (queryIndex != -1) {
                let query = window.location.href.slice(queryIndex);
                let params = new URLSearchParams(query);
                if (params.has('code')) {
                    this.code = params.get('code');
                    checkIn();
                }
            }
            return true;
        }
    }
});

function updateCheckInMap() {
    //if (document.getElementById('check-in-map') != undefined) {
        mapboxgl.accessToken = 'pk.eyJ1Ijoid2RjLXByb2plY3QiLCJhIjoiY2tvYzlsNW54MHNqZTMwb3k1ZjJlM3d2YyJ9.uD5DPRQ6JiUzECtpkOw8LA';
        var checkinMap = new mapboxgl.Map({
            container: 'check-in-map',
            style: 'mapbox://styles/mapbox/streets-v11',
            center: [138.602668, -34.920741],
            zoom: 9
        });
    //}

    var xhttp = new XMLHttpRequest();

    xhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            vm.checkins = JSON.parse(this.responseText);

            for (let checkin of vm.checkins) {
                let marker = new mapboxgl.Marker()
                .setLngLat([checkin.longitude, checkin.latitude])
                .addTo(checkinMap);
            }
        }
    };

    xhttp.open("GET", "/user/check-in-history", true);
    xhttp.send();
}

function updateHotspotMap() {
    //if (document.getElementById('hotspot-map') != undefined) {
        mapboxgl.accessToken = 'pk.eyJ1Ijoid2RjLXByb2plY3QiLCJhIjoiY2tvYzlsNW54MHNqZTMwb3k1ZjJlM3d2YyJ9.uD5DPRQ6JiUzECtpkOw8LA';
        var map = new mapboxgl.Map({
            container: 'hotspot-map',
            style: 'mapbox://styles/mapbox/streets-v11',
            center: [138.602668, -34.920741],
            zoom: 9
        });
    //}

    var xhttp = new XMLHttpRequest();

    xhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            let hotspots = JSON.parse(this.responseText);
            vm.hotspot_venues = hotspots.venues;
            vm.hotspot_areas = hotspots.areas;

            if (map !== undefined) {
                // Mark hotspot venues:
                for (let venue of vm.hotspot_venues) {
                    let marker = new mapboxgl.Marker()
                    .setLngLat([venue.longitude, venue.latitude])
                    .addTo(map);
                }

                // Mark hotspot areas:
                for (let area of vm.hotspot_areas) {
                    let id = area.city;
                    map.addSource(id, {
                        'type': 'geojson',
                        'data': {
                        'type': 'Feature',
                        'geometry': {
                            'type': 'Polygon',
                            'coordinates': area.coords
                            }
                        }
                    });

                    map.addLayer({
                        'id': id,
                        'type': 'fill',
                        'source': id,
                        'layout': {},
                        'paint': {
                            'fill-color': '#ff0000',
                            'fill-opacity': 0.5
                        }
                    });

                    map.addLayer({
                        'id': id + ' outline',
                        'type': 'line',
                        'source': id,
                        'layout': {},
                        'paint': {
                            'line-color': '#000000',
                            'line-width': 3
                        }
                    });
                }
            }
        }
    };

    xhttp.open("GET", "/user/hotspots", true);
    xhttp.send();
}

function pageChanged() {
    vm.page = location.hash.slice(2);
    let queryIndex = vm.page.indexOf('?', 0);
    if (queryIndex != -1) {
        vm.page = vm.page.slice(0, queryIndex);
    }

    let nav = document.getElementsByTagName('nav')[0];
    for (let page of nav.children[0].children) {
        if (window.location.href == page.children[0].href) {
            page.children[0].classList.add('current-page');
        } else {
            if (page.children[0].classList.contains('current-page')) {
                page.children[0].classList.remove('current-page');
            }
        }
    }
}

window.onhashchange = pageChanged;
pageChanged();

// Dashboard
var dataURL = "https://raw.githubusercontent.com/covid-19-au/covid-19-au.github.io/prod/src/data/state.json";
var states = ["NSW", "QLD", "VIC", "SA", "WA", "TAS", "ACT", "NT"];

function getCovidData() {
    var xhttp = new XMLHttpRequest();

    xhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            let rawData = JSON.parse(this.responseText);
            let keys = Object.keys(rawData);
            let latest = rawData[keys[keys.length - 1]];
            let lastWeek = rawData[keys[keys.length - 8]];

            let caseData = [];
            for (let s of states) {
                caseData.push({state: s, active: latest[s][4], total: latest[s][0]});
            }

            let deathData = [];
            for (let s of states) {
                deathData.push({state: s, active: latest[s][1] - lastWeek[s][1], total: latest[s][1]});
            }

            vm.cases = caseData;
            vm.deaths = deathData;

            // TODO: Implement case chart:
            /*
            casesChart.data.datasets[0].data = [];
            casesChart.data.datasets[0].data.push(vm.cases[0].total);
            casesChart.update();*/
        }
    };

    xhttp.open("GET", dataURL, true);

    xhttp.send();
}

vm.info = [
    {state: "ACT", url: "https://www.covid19.act.gov.au/"},
    {state: "NSW", url: "https://www.nsw.gov.au/covid-19"},
    {state: "NT", url: "https://coronavirus.nt.gov.au/"},
    {state: "QLD", url: "https://www.covid19.qld.gov.au/"},
    {state: "SA", url: "https://www.covid-19.sa.gov.au/"},
    {state: "TAS", url: "https://coronavirus.tas.gov.au/"},
    {state: "VIC", url: "https://www.dhhs.vic.gov.au/coronavirus"},
    {state: "WA", url: "https://www.wa.gov.au/government/covid-19-coronavirus"}
];

// Load user settings:
var settingsCookie = decodeURIComponent(document.cookie);
var cookieParts = settingsCookie.split(';');
var cookieKey = "settings=";
var cookieKeyUser = "userType=";

for (let part of cookieParts) {
    part = part.trim();
    if (part.indexOf(cookieKey) == 0) {
        vm.settings = JSON.parse(part.substring(cookieKey.length + 1, part.length - 1));
    } else if (part.indexOf(cookieKeyUser) == 0) {
        vm.user.accountType = part.substring(cookieKeyUser.length, part.length);
    }
}

// Create new settings object:
if (vm.settings === undefined) {
    vm.settings = {
        dashCases: true,
        dashDeaths: true,
        dashInfo: true
    };
    let expiry = new Date() + new Date(10 * 365 * 24 * 60 * 60 * 1000);
    document.cookie = `settings="${JSON.stringify(vm.settings)}";path=/;expires=${expiry.toString()}`;
}

getCovidData();

vm.hotspot_visit = 0;

// Check-in
function checkIn() {
    var xhttp = new XMLHttpRequest();

    xhttp.onreadystatechange = function() {
        if (this.readyState == 4) {
            if (this.status == 200) {
                let responseJSON = JSON.parse(this.responseText);
                vm.checkin = {
                    venue: responseJSON.venue,
                    time: new Date(responseJSON.time).toLocaleString(),
                    address: responseJSON.address
                };
                vm.checkin_status = 1;
            } else {
                vm.checkin_status = 0;
            }
        }
    };

    xhttp.open("POST", "/user/check-in", true);
    xhttp.setRequestHeader('Content-type', 'application/json');
    xhttp.send(JSON.stringify({code: vm.code}));

    return false;
}

// Settings
function revertSettings() {
    location.reload();
}

function applySettings() {
    /*
    let newSettings = {
        dashCases: document.getElementById('dash-cases').checked,
        dashDeaths: document.getElementById('dash-deaths').checked,
        dashInfo: document.getElementById('dash-info').checked
    };

    vm.settings = newSettings;
*/
    let expiry = new Date() + new Date(10 * 365 * 24 * 60 * 60 * 1000);
    document.cookie = `settings="${JSON.stringify(vm.settings)}";path=/;expires=${expiry.toString()}`;

    return false;
}

// Manage Users
var allUsers = [];

function search() {
    vm.pg = 1;
    getUsers(vm.page_size, vm.viewPage);
    return false;
}

function getUsers(size, page) {
    var xhttp = new XMLHttpRequest();

    xhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            allUsers = JSON.parse(this.responseText);

            let results = [];
            for (let user of allUsers) {
                if (user[vm.search_data.by].toString().toLowerCase().includes(vm.search_data.term.toString().toLowerCase())) {
                    results.push(user);
                }
            }
            vm.users = results.slice((page - 1) * size, page * size);
        }
    };

    xhttp.open("GET", "/fakedata/users.json", true);

    xhttp.send();
}

function setPage(delta) {
    vm.pg = Math.max(1, parseInt(vm.pg) + delta);
    getUsers(vm.page_size, vm.viewPage);
}

function stopManagingUser() {
    vm.managing_user = false;
    return false;
}

function stopViewingCheckins() {
    vm.viewing_checkins = false;
    return false;
}

// Manage Venues
var allVenues = [];

function searchVenue() {
    vm.pg = 1;
    getVenues(vm.page_size, vm.viewPage);
    return false;
}

function getVenues(size, page) {
    var xhttp = new XMLHttpRequest();

    xhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            allVenues = JSON.parse(this.responseText);

            let results = [];
            for (let venue of allVenues) {
                if (venue[vm.search_data.by].toString().toLowerCase().includes(vm.search_data.term.toString().toLowerCase())) {
                    results.push(venue);
                }
            }
            vm.venues = results.slice((page - 1) * size, page * size);
        }
    };

    xhttp.open("GET", "/fakedata/venues.json", true);

    xhttp.send();
}

function setVenuePage(delta) {
    vm.pg = Math.max(1, parseInt(vm.pg) + delta);
    getVenues(vm.page_size, vm.viewPage);
}

function stopManagingVenue() {
    vm.managing_venue = false;
    return false;
}

function stopViewingVenueCheckins() {
    vm.viewing_checkins = false;
    return false;
}

function stopViewingOwner() {
    vm.viewing_owner = false;
    return false;
}


function registerHealthOfficial() {
    let email = document.getElementById('email').value;

    var xhttp = new XMLHttpRequest();

    xhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            vm.pending = JSON.parse(this.responseText);
        }
    };

    xhttp.open("POST", "/admin/register-health-official", true);

    xhttp.send(email);
}

function toggleNavMenu() {
    let navmenu = document.getElementsByTagName('nav')[0];
    if (navmenu.hidden == false) {
        navmenu.hidden = true;
        window.removeEventListener("click", hideNav);
    } else {
        navmenu.hidden = false;
        window.setTimeout(() => { window.addEventListener("click", hideNav); }, 0);
    }
}

function hideNav(event) {
    let width = window.matchMedia("(max-width: 768px)");
    if (width.matches) {
        toggleNavMenu();
    }
}

function signOut() {
    var xhttp = new XMLHttpRequest();

    xhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            document.cookie = "userType=;path=/";
            window.location.href = "/login.html";
        }
    };

    xhttp.open("POST", "/user/logout", true);

    xhttp.send();

    // Google sign out:
    var auth2 = gapi.auth2.getAuthInstance();
    auth2.signOut().then(function () {
        console.log('User signed out.');
    });
}