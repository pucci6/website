var footer = document.getElementsByTagName('footer')[0];
/* TODO: Add links to privacy, etc. pages.
footer.innerHTML = `<div>
                <a>Some link...</a>
                <a>Some link...</a>
                <a>Some link...</a>
            </div>`;*/