var vm = new Vue({
    el: '#app',
    data: {
        checkins: []
    }
});

var xhttp = new XMLHttpRequest();

xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
        vm.checkins = JSON.parse(this.responseText);
    }
};

xhttp.open("GET", "/manager/check-in-history", true);
xhttp.send();