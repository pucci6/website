var vm = new Vue({
    el: '#app',
    data: {
        checkins: []
    }
});

mapboxgl.accessToken = 'pk.eyJ1Ijoid2RjLXByb2plY3QiLCJhIjoiY2tvYzlsNW54MHNqZTMwb3k1ZjJlM3d2YyJ9.uD5DPRQ6JiUzECtpkOw8LA';
var map = new mapboxgl.Map({
    container: 'map',
    style: 'mapbox://styles/mapbox/streets-v11',
    center: [138.602668, -34.920741],
    zoom: 9
});

var xhttp = new XMLHttpRequest();

xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
        vm.checkins = JSON.parse(this.responseText);

        for (let checkin of vm.checkins) {
            let marker = new mapboxgl.Marker()
            .setLngLat([checkin.longitude, checkin.latitude])
            .addTo(map);
        }
    }
};

xhttp.open("GET", "/user/check-in-history", true);
xhttp.send();