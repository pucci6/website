CREATE TABLE check_in
(
  check_in_id INT NOT NULL,
  user INT NOT NULL,
  venue INT NOT NULL,
  timestamp DATE NOT NULL,
  PRIMARY KEY (check_in_id),
  FOREIGN KEY (user) REFERENCES account(user_id),
  FOREIGN KEY (venue) REFERENCES venue(venue_id)
);

CREATE TABLE venue
(
  venue_id INT NOT NULL,
  name VARCHAR(100) NOT NULL,
  owner INT NOT NULL,
  latitude FLOAT NOT NULL,
  longitude FLOAT NOT NULL,
  state VARCHAR(3) NOT NULL,
  city VARCHAR(50) NOT NULL,
  postcode INT NOT NULL,
  street_name VARCHAR(50) NOT NULL,
  street_number VARCHAR(20) NOT NULL,
  PRIMARY KEY (venue_id),
  FOREIGN KEY (owner) REFERENCES account(user_id)
);

CREATE TABLE hotspot_area
(
  hotspot_id INT NOT NULL,
  start_time DATETIME NOT NULL,
  end_time DATETIME NOT NULL,
  state VARCHAR(3) NOT NULL,
  city VARCHAR(50) NOT NULL,
  postcode INT NOT NULL,
  PRIMARY KEY (hotspot_id)
);

CREATE TABLE hotspot_venue
(
  hotspot_id INT NOT NULL,
  venue INT NOT NULL,
  start_time DATETIME NOT NULL,
  end_time DATETIME NOT NULL,
  PRIMARY KEY (hotspot_id),
  FOREIGN KEY (venue) REFERENCES venue(venue_id)
);

CREATE TABLE account
(
  user_id INT NOT NULL AUTO_INCREMENT,
  given_name VARCHAR(50) NOT NULL,
  family_name VARCHAR(50) NOT NULL,
  email VARCHAR(100) NOT NULL,
  phone VARCHAR(16) NOT NULL,
  password_hash VARCHAR(128) NOT NULL,
  account_type VARCHAR(16) NOT NULL,
  PRIMARY KEY (user_id)
);

CREATE TABLE pending_admin
(
  email VARCHAR(100),
  code VARCHAR(32),
  expiry DATETIME,
  PRIMARY KEY (email)
);