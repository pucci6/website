function checkIn() {
    var xhttp = new XMLHttpRequest();

    xhttp.onreadystatechange = function() {
        if (this.readyState == 4) {
            if (this.status == 200) {
                let responseJSON = JSON.parse(this.responseText);
                vm.checkin = {
                    venue: responseJSON.venue,
                    time: responseJSON.time.toLocaleString()
                };
                vm.checkin_status = 1;
            } else {
                vm.checkin_status = 0;
            }
        }
    };

    xhttp.open("POST", "/user/check-in", true);
    xhttp.setRequestHeader('Content-type', 'application/json');
    xhttp.send(JSON.stringify({code: vm.code}));

    return false;
}

var vm = new Vue({
    el: '#app',
    data: {
        code: '',
        checkin_status: -1,
        checkin: {}
    }
});