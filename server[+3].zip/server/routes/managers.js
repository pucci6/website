var express = require('express');
var router = express.Router();

router.get('/check-in-history', function(req, res, next) {
    res.json([{"familyName":"Shaw","givenName":"Zac","date":"13/05/2021","time":"7:09 PM"},{"familyName":"Walker","givenName":"Abby","date":"13/05/2021","time":"6:28 PM"},
    {"familyName":"Kelly","givenName":"Brandon","date":"13/05/2021","time":"6:24 PM"},{"familyName":"Ross","givenName":"Madeleine","date":"13/05/2021","time":"5:45 PM"},
    {"familyName":"Cooper","givenName":"Chelsea","date":"13/05/2021","time":"4:51 PM"},{"familyName":"Parker","givenName":"Harry","date":"13/05/2021","time":"4:01 PM"},
    {"familyName":"Young","givenName":"Max","date":"13/05/2021","time":"3:09 PM"},{"familyName":"Hamilton","givenName":"Aaron","date":"13/05/2021","time":"2:49 PM"},
    {"familyName":"Mitchell","givenName":"Steph","date":"13/05/2021","time":"2:16 PM"},{"familyName":"Walker","givenName":"Jacinta","date":"13/05/2021","time":"2:09 PM"},
    {"familyName":"Shaw","givenName":"Ellie","date":"13/05/2021","time":"1:52 PM"},{"familyName":"Chapman","givenName":"Corey","date":"13/05/2021","time":"1:48 PM"},
    {"familyName":"Butler","givenName":"Sean","date":"13/05/2021","time":"1:32 PM"},{"familyName":"Phillips","givenName":"Shaun","date":"13/05/2021","time":"1:06 PM"},
    {"familyName":"McDonald","givenName":"Luke","date":"13/05/2021","time":"12:50 PM"},{"familyName":"Davis","givenName":"Brooke","date":"13/05/2021","time":"12:22 PM"},
    {"familyName":"Edwards","givenName":"Chelsea","date":"13/05/2021","time":"11:47 AM"},{"familyName":"Hall","givenName":"Charlie","date":"13/05/2021","time":"11:22 AM"},
    {"familyName":"Stevens","givenName":"Harrison","date":"13/05/2021","time":"11:22 AM"},{"familyName":"Reid","givenName":"Jade","date":"13/05/2021","time":"10:54 AM"},
    {"familyName":"Gray","givenName":"Brandon","date":"13/05/2021","time":"10:02 AM"},{"familyName":"Baker","givenName":"Steven","date":"13/05/2021","time":"9:04 AM"},
    {"familyName":"Ryan","givenName":"Matthew","date":"13/05/2021","time":"8:29 AM"},{"familyName":"Davies","givenName":"Connor","date":"13/05/2021","time":"7:41 AM"},
    {"familyName":"Johnston","givenName":"Maddie","date":"13/05/2021","time":"7:19 AM"},{"familyName":"Morris","givenName":"Riley","date":"13/05/2021","time":"6:44 AM"},
    {"familyName":"Richardson","givenName":"Hamish","date":"13/05/2021","time":"6:34 AM"},{"familyName":"Jackson","givenName":"Shaun","date":"13/05/2021","time":"6:18 AM"},
    {"familyName":"Carter","givenName":"Leah","date":"13/05/2021","time":"6:17 AM"},{"familyName":"Taylor","givenName":"Madison","date":"13/05/2021","time":"5:24 AM"},
    {"familyName":"Young","givenName":"Jessie","date":"13/05/2021","time":"5:23 AM"},{"familyName":"Stevens","givenName":"Ryan","date":"13/05/2021","time":"4:27 AM"},
    {"familyName":"Morris","givenName":"Chris","date":"13/05/2021","time":"3:59 AM"},{"familyName":"Shaw","givenName":"Sean","date":"13/05/2021","time":"3:30 AM"},
    {"familyName":"Morgan","givenName":"Samantha","date":"13/05/2021","time":"2:45 AM"},{"familyName":"Graham","givenName":"Rachael","date":"13/05/2021","time":"1:54 AM"},
    {"familyName":"Chapman","givenName":"Mark","date":"13/05/2021","time":"12:59 AM"},{"familyName":"Wood","givenName":"Tony","date":"13/05/2021","time":"12:06 AM"},
    {"familyName":"Clark","givenName":"Nicole","date":"12/05/2021","time":"11:34 PM"},{"familyName":"Rogers","givenName":"Jim","date":"12/05/2021","time":"10:46 PM"},
    {"familyName":"Edwards","givenName":"Kieran","date":"12/05/2021","time":"9:49 PM"},{"familyName":"Carter","givenName":"Tegan","date":"12/05/2021","time":"9:34 PM"},
    {"familyName":"Thomson","givenName":"Kyle","date":"12/05/2021","time":"8:41 PM"},{"familyName":"Matthews","givenName":"Sophie","date":"12/05/2021","time":"8:30 PM"},
    {"familyName":"Mitchell","givenName":"Scott","date":"12/05/2021","time":"8:17 PM"},{"familyName":"Miller","givenName":"Bethany","date":"12/05/2021","time":"7:40 PM"},
    {"familyName":"Davies","givenName":"Connor","date":"12/05/2021","time":"6:42 PM"},{"familyName":"Thompson","givenName":"Jessie","date":"12/05/2021","time":"6:18 PM"},
    {"familyName":"Hughes","givenName":"Brayden","date":"12/05/2021","time":"5:59 PM"},{"familyName":"Nguyen","givenName":"Caitlyn","date":"12/05/2021","time":"5:00 PM"},
    {"familyName":"Carter","givenName":"Jim","date":"12/05/2021","time":"4:46 PM"},{"familyName":"Green","givenName":"Julia","date":"12/05/2021","time":"3:56 PM"},
    {"familyName":"Harvey","givenName":"Annie","date":"12/05/2021","time":"3:17 PM"},{"familyName":"Roberts","givenName":"Ryan","date":"12/05/2021","time":"2:26 PM"},
    {"familyName":"Hamilton","givenName":"Abby","date":"12/05/2021","time":"2:15 PM"},{"familyName":"Murray","givenName":"Rachael","date":"12/05/2021","time":"1:21 PM"},
    {"familyName":"Cook","givenName":"Grace","date":"12/05/2021","time":"12:52 PM"},{"familyName":"Graham","givenName":"Brooke","date":"12/05/2021","time":"12:30 PM"},
    {"familyName":"Jackson","givenName":"Hamish","date":"12/05/2021","time":"11:43 AM"},{"familyName":"Stewart","givenName":"Bella","date":"12/05/2021","time":"11:10 AM"},
    {"familyName":"Robinson","givenName":"Tim","date":"12/05/2021","time":"10:52 AM"},{"familyName":"Young","givenName":"Jackson","date":"12/05/2021","time":"10:41 AM"},
    {"familyName":"Harvey","givenName":"Aaron","date":"12/05/2021","time":"10:37 AM"},{"familyName":"Murray","givenName":"Jessica","date":"12/05/2021","time":"9:53 AM"},
    {"familyName":"Green","givenName":"Abbie","date":"12/05/2021","time":"9:35 AM"},{"familyName":"Cameron","givenName":"Erin","date":"12/05/2021","time":"8:52 AM"},
    {"familyName":"Johnston","givenName":"Shane","date":"12/05/2021","time":"8:14 AM"},{"familyName":"White","givenName":"Stephanie","date":"12/05/2021","time":"7:54 AM"},
    {"familyName":"Allen","givenName":"Hugo","date":"12/05/2021","time":"7:53 AM"},{"familyName":"Martin","givenName":"Claire","date":"12/05/2021","time":"7:48 AM"},
    {"familyName":"Jones","givenName":"Kevin","date":"12/05/2021","time":"6:56 AM"},{"familyName":"Adams","givenName":"Kate","date":"12/05/2021","time":"6:36 AM"},
    {"familyName":"Robertson","givenName":"Mitch","date":"12/05/2021","time":"6:31 AM"},{"familyName":"Taylor","givenName":"Jonathan","date":"12/05/2021","time":"6:18 AM"},
    {"familyName":"Taylor","givenName":"Steven","date":"12/05/2021","time":"5:30 AM"},{"familyName":"Morgan","givenName":"Shaun","date":"12/05/2021","time":"5:28 AM"},
    {"familyName":"Hamilton","givenName":"William","date":"12/05/2021","time":"4:29 AM"},{"familyName":"Walker","givenName":"Taylor","date":"12/05/2021","time":"3:40 AM"},
    {"familyName":"James","givenName":"Jessica","date":"12/05/2021","time":"3:26 AM"},{"familyName":"Harrison","givenName":"Matthew","date":"12/05/2021","time":"2:50 AM"},
    {"familyName":"Wilson","givenName":"Brock","date":"12/05/2021","time":"2:41 AM"},{"familyName":"Hill","givenName":"Grace","date":"12/05/2021","time":"2:31 AM"},
    {"familyName":"Carter","givenName":"Lauren","date":"12/05/2021","time":"2:00 AM"},{"familyName":"Taylor","givenName":"Isaac","date":"12/05/2021","time":"1:13 AM"},
    {"familyName":"Wright","givenName":"Riley","date":"12/05/2021","time":"12:14 AM"},{"familyName":"Pearce","givenName":"Olivia","date":"12/05/2021","time":"12:05 AM"},
    {"familyName":"Harris","givenName":"Molly","date":"12/05/2021","time":"12:00 AM"},{"familyName":"Allen","givenName":"Zachary","date":"11/05/2021","time":"11:05 PM"},
    {"familyName":"Richardson","givenName":"Madeleine","date":"11/05/2021","time":"10:28 PM"},{"familyName":"James","givenName":"Blake","date":"11/05/2021","time":"9:46 PM"},
    {"familyName":"Richardson","givenName":"Claudia","date":"11/05/2021","time":"8:51 PM"},{"familyName":"Ward","givenName":"Julia","date":"11/05/2021","time":"7:54 PM"},
    {"familyName":"Ward","givenName":"Julia","date":"11/05/2021","time":"7:52 PM"},{"familyName":"Chapman","givenName":"Josh","date":"11/05/2021","time":"6:52 PM"},
    {"familyName":"Hughes","givenName":"Claudia","date":"11/05/2021","time":"5:59 PM"},{"familyName":"Clarke","givenName":"Lauren","date":"11/05/2021","time":"5:41 PM"},
    {"familyName":"Elliott","givenName":"Bianca","date":"11/05/2021","time":"4:41 PM"},{"familyName":"Stevens","givenName":"Jade","date":"11/05/2021","time":"3:51 PM"},
    {"familyName":"Matthews","givenName":"Taylor","date":"11/05/2021","time":"3:18 PM"},{"familyName":"Elliott","givenName":"Gus","date":"11/05/2021","time":"2:51 PM"}]);
});

var testvenue = {
    name: "My Business",
    streetNo: "12A",
    streetName: "First Street",
    city: "Adelaide",
    postcode: 5000
};

router.get('/details', function(req, res, next) {
    res.json(testvenue);
});

router.post('/details', function(req, res, next) {
    testvenue = req.body;
    res.sendStatus(200);
});

function parseVenueCode(code) {
    code = code.toUpperCase();
    let result = 1;
    let scale = 1;
    for (let i = 0; i < code.length; i++) {
        let charCode = code.charCodeAt(i);
        if (charCode > 64) {
            charCode -= 65;
        } else {
            charCode -= 22;
        }
        result += charCode * scale;
        scale *= 36;
    }
    return result;
}

router.get('/check-in-printable', function(req, res, next) {
    let user = req.session.user.user_id;

    req.pool.getConnection(function(err, connection) {
       if (err) {
           console.log(err);
           res.sendStatus(500);
           return;
       }

       var query = "SELECT * FROM venue WHERE owner = ?;";
       connection.query(query, [user], function(err, rows, fields) {
           connection.release();
           if (err) {
               console.log(err);
               res.sendStatus(500);
               return;
            }

            if (rows.length > 0) {
                res.json({
                    address: `${rows[0].street_number} ${rows[0].street_name}, ${rows[0].city} ${rows[0].postcode} ${rows[0].state}`,
                    name: rows[0].name,
                    code: parseVenueCode(rows[0].venue_id.toString())
                });
            } else {
                res.sendStatus(500);
            }
        });
    });
});

module.exports = router;