// TODO: Create chart to display daily case numbers.

/*
const labels = [
  'January',
  'February',
  'March',
  'April',
  'May',
  'June'
];

const chart_data = {
  labels: labels,
  datasets: [{
    label: 'SA',
    backgroundColor: 'rgb(255, 99, 132)',
    borderColor: 'rgb(255, 99, 132)',
    data: []
  }]
};

const config = {
  type: 'line',
  data: chart_data,
  options: {
      plugins: {
          legend: {
              position: 'right'
          }
      }
  }
};

var casesChart = new Chart(
    document.getElementById('cases-chart'),
    config
);

*/