function revert() {
    location.reload();
}

function apply() {
    // Send POST request to server, containing the updated venue details.
    var xhttp = new XMLHttpRequest();

    xhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            location.reload();
        }
    };

    xhttp.open("POST", "/manager/details", true);
    xhttp.setRequestHeader('Content-type', 'application/json');
    xhttp.send(JSON.stringify(vm.venue));
}

var vm = new Vue({
    el: '#app',
    data: {
        venue: {}
    }
});

var xhttp = new XMLHttpRequest();

xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
        vm.venue = JSON.parse(this.responseText);
    }
};

xhttp.open("GET", "/manager/details", true);
xhttp.send();