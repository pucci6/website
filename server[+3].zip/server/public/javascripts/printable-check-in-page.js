var xhttp = new XMLHttpRequest();

xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
        let data = JSON.parse(this.responseText);
        var qr = new QRCode(document.getElementById('qr'), window.location.hostname + "/#/check-in?code=" + data.code);
        document.getElementById('qr').getElementsByTagName('img')[0].classList.add("centred");
        document.getElementById('qr').getElementsByTagName('img')[0].classList.add("full-width");

        document.getElementById('code').innerText = data.code;
        document.getElementById('venue-name').innerText = data.name;
        document.getElementById('venue-address').innerText = data.address;
    }
};

xhttp.open("GET", "/manager/check-in-printable", true);
xhttp.send();