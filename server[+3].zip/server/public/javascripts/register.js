var vm = new Vue({
    el: '#app',
    data: {
        venue_owner: false,
        user: {
            givenName: "",
            familyName: "",
            email: "",
            phone: "",
            password: ""
        },
        venue: {
            name: "",
            streetNo: "",
            streetName: "",
            city: "",
            postcode: ""
        }
    }
});

function back() {
    window.location.href = "/login.html";
}

function register() {
    if (vm.venue_owner) {
        vm.user.venue = vm.venue;
    }

    var xhttp = new XMLHttpRequest();

    xhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            window.location.href = '/login.html';
        }
    };

    xhttp.open("POST", "/register", true);
    xhttp.setRequestHeader('Content-type', 'application/json');
    xhttp.send(JSON.stringify(vm.user));

    return false;
}

function validatePassword() {
    var password = document.getElementById("password");
    var confirmPassword = document.getElementById("password-confirm");

    if (String(password.value) != String(confirmPassword.value)) {
        confirmPassword.setCustomValidity("Passwords must match.");
    } else {
        confirmPassword.setCustomValidity("");
    }
}