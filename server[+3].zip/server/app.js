var express = require('express');
var path = require('path');
var cookieParser = require('cookie-parser');
var logger = require('morgan');
var session = require('express-session');
var mysql = require('mysql');

var indexRouter = require('./routes/index');
var usersRouter = require('./routes/users');
var managersRouter = require('./routes/managers');
var adminsRouter = require('./routes/admins');

var dbConnectionPool = mysql.createPool({
    host: 'localhost',
    database: 'covid'
});

var app = express();

app.use(function(req, res, next) {
    req.pool = dbConnectionPool;
    next();
});

app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());

app.use(session({
    secret: "My Secret",
    resave: false,
    saveUninitialized: true,
    cookie: { secure: false }
}));

app.use('/', indexRouter);
app.use(express.static(path.join(__dirname, 'public')));

app.use('/user', usersRouter);
app.use(express.static(path.join(__dirname, 'user')));

app.use('/manager', managersRouter);
app.use(express.static(path.join(__dirname, 'manager')));

app.use('/admin', adminsRouter);
app.use(express.static(path.join(__dirname, 'admin')));

module.exports = app;
